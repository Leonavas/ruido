Spree::Role.create!(:name => "admin")
Spree::Role.create!(:name => "user")
