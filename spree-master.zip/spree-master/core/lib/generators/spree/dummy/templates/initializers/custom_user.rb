# Spree.user_class = "User"
