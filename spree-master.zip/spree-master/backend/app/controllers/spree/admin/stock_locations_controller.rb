module Spree
  module Admin
    class StockLocationsController < ResourceController

    end
  end
end
