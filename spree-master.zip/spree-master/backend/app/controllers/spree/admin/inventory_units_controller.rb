module Spree
  module Admin
    class InventoryUnitsController < Spree::Admin::BaseController
    end
  end
end