require 'spree/api'
require 'spree/api/responders'
require 'versioncake'
