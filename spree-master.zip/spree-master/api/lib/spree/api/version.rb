module Spree
  module Api
    VERSION = "1.1.0.beta"
  end
end
